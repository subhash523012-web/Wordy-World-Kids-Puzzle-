package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.SoundManager
import com.example.model.CellPos
import com.example.model.GameLevel
import com.example.model.GameLevelsRepository
import com.example.model.PlacedWord
import com.example.model.WordClue
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class GameUiState(
    val currentLevelIndex: Int = 0,
    val activeLevel: GameLevel = GameLevelsRepository.levels[0],
    val gridLetters: List<List<Char>> = emptyList(),
    val placedWords: List<PlacedWord> = emptyList(),
    val foundWords: Set<String> = emptySet(),
    val selectedCells: List<CellPos> = emptyList(),
    val wrongCells: Set<CellPos> = emptySet(),
    val laserHintCells: Set<CellPos> = emptySet(),
    val wrongAttempts: Int = 0,
    val combo: Int = 1,
    val bonusTrigger: Int = 0,
    val soundEnabled: Boolean = true,
    val isLevelComplete: Boolean = false,
    val isLevelSelectorOpen: Boolean = false
) {
    val totalWordsCount: Int get() = activeLevel.words.size
    val foundWordsCount: Int get() = foundWords.size
    val progressFraction: Float
        get() = if (totalWordsCount == 0) 0f else foundWordsCount.toFloat() / totalWordsCount

    val currentClue: WordClue?
        get() = activeLevel.words.firstOrNull { it.word !in foundWords }

    val flatLetters: List<String>
        get() = gridLetters.flatMap { row -> row.map { it.toString() } }
}

class GameViewModel(
    val soundManager: SoundManager = SoundManager()
) : ViewModel() {

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    private var isDragging = false

    init {
        loadLevel(0)
    }

    fun loadLevel(index: Int) {
        val totalLevels = GameLevelsRepository.levels.size
        val normalizedIndex = when {
            index < 0 -> 0
            index >= totalLevels -> 0
            else -> index
        }
        val level = GameLevelsRepository.levels[normalizedIndex]
        val boardResult = GameLevelsRepository.generateBoard(level)

        _uiState.update {
            it.copy(
                currentLevelIndex = normalizedIndex,
                activeLevel = level,
                gridLetters = boardResult.grid,
                placedWords = boardResult.placedWords,
                foundWords = emptySet(),
                selectedCells = emptyList(),
                wrongCells = emptySet(),
                laserHintCells = emptySet(),
                wrongAttempts = 0,
                combo = 1,
                isLevelComplete = false,
                isLevelSelectorOpen = false
            )
        }
    }

    fun nextLevel() {
        val nextIdx = (_uiState.value.currentLevelIndex + 1) % GameLevelsRepository.levels.size
        loadLevel(nextIdx)
    }

    fun prevLevel() {
        val prevIdx = if (_uiState.value.currentLevelIndex > 0) {
            _uiState.value.currentLevelIndex - 1
        } else {
            GameLevelsRepository.levels.size - 1
        }
        loadLevel(prevIdx)
    }

    fun toggleAudio() {
        val newState = !_uiState.value.soundEnabled
        soundManager.soundEnabled = newState
        _uiState.update { it.copy(soundEnabled = newState) }
    }

    fun openLevelSelector(open: Boolean) {
        _uiState.update { it.copy(isLevelSelectorOpen = open) }
    }

    fun useLaserHint() {
        val state = _uiState.value
        val targetClue = state.currentClue ?: return
        val placed = state.placedWords.find { it.word == targetClue.word } ?: return

        soundManager.playLaserSound()
        _uiState.update { it.copy(laserHintCells = placed.cells.toSet()) }

        viewModelScope.launch {
            delay(2800)
            _uiState.update { it.copy(laserHintCells = emptySet()) }
        }
    }

    fun useTimeWarp() {
        soundManager.playWarpSound()
        _uiState.update { it.copy(bonusTrigger = it.bonusTrigger + 2) }
    }

    fun onTileIndexClick(index: Int) {
        val state = _uiState.value
        val size = state.activeLevel.gridSize
        if (size <= 0) return
        val r = index / size
        val c = index % size
        onCellTap(CellPos(r, c))
    }

    // MODE A: Tap to auto-select if starting letter matches unfound word or toggle/build word
    fun onCellTap(pos: CellPos) {
        val state = _uiState.value
        val unfound = state.placedWords.filter { it.word !in state.foundWords }
        val autoMatch = unfound.find { it.cells.firstOrNull() == pos }

        if (autoMatch != null) {
            // Instantly select all cells of this word and validate!
            _uiState.update { it.copy(selectedCells = autoMatch.cells) }
            validateSelection(autoMatch.cells)
        } else {
            // Toggle cell in selected list
            val updated = if (pos in state.selectedCells) {
                state.selectedCells - pos
            } else {
                state.selectedCells + pos
            }

            _uiState.update { it.copy(selectedCells = updated) }

            // Check if updated forms any unfound word
            if (updated.isNotEmpty()) {
                val grid = state.gridLetters
                val candidateWord = updated.mapNotNull { p ->
                    if (p.r in grid.indices && p.c in grid[p.r].indices) grid[p.r][p.c] else null
                }.joinToString("")

                val match = unfound.find { it.word == candidateWord }
                if (match != null) {
                    validateSelection(updated)
                }
            }
        }
    }

    // MODE B: Swipe gestures
    fun onDragStart(pos: CellPos) {
        isDragging = true
        _uiState.update {
            it.copy(
                selectedCells = listOf(pos),
                wrongCells = emptySet()
            )
        }
    }

    fun onDragMove(pos: CellPos) {
        if (!isDragging) return
        val currentSelected = _uiState.value.selectedCells
        if (currentSelected.isEmpty()) {
            _uiState.update { it.copy(selectedCells = listOf(pos)) }
            return
        }

        if (pos in currentSelected) return

        val first = currentSelected[0]
        val isCollinear = when {
            currentSelected.size == 1 -> {
                pos.r == first.r || pos.c == first.c
            }
            currentSelected[0].r == currentSelected[1].r -> {
                pos.r == first.r
            }
            currentSelected[0].c == currentSelected[1].c -> {
                pos.c == first.c
            }
            else -> false
        }

        if (isCollinear) {
            _uiState.update { it.copy(selectedCells = currentSelected + pos) }
        }
    }

    fun onDragEnd() {
        if (!isDragging) return
        isDragging = false
        validateSelection(_uiState.value.selectedCells)
    }

    fun onDragCancel() {
        isDragging = false
        _uiState.update { it.copy(selectedCells = emptyList()) }
    }

    private fun validateSelection(cellsToValidate: List<CellPos>) {
        if (cellsToValidate.isEmpty()) return

        val state = _uiState.value
        val grid = state.gridLetters
        if (grid.isEmpty()) return

        val selectedWord = cellsToValidate.mapNotNull { pos ->
            if (pos.r in grid.indices && pos.c in grid[pos.r].indices) {
                grid[pos.r][pos.c]
            } else null
        }.joinToString("")

        val target = state.placedWords.find {
            it.word == selectedWord && it.word !in state.foundWords
        }

        if (target != null) {
            // Correct selection!
            val updatedFound = state.foundWords + target.word
            soundManager.playCorrectSound()
            val complete = updatedFound.size == state.activeLevel.words.size

            _uiState.update {
                it.copy(
                    foundWords = updatedFound,
                    selectedCells = emptyList(),
                    wrongCells = emptySet(),
                    combo = it.combo + 1,
                    bonusTrigger = it.bonusTrigger + 1,
                    isLevelComplete = complete
                )
            }

            if (complete) {
                viewModelScope.launch {
                    delay(300)
                    soundManager.playCompleteSound()
                }
            }
        } else {
            // Wrong selection!
            soundManager.playWrongSound()
            val wrongSet = cellsToValidate.toSet()

            _uiState.update {
                it.copy(
                    wrongAttempts = it.wrongAttempts + 1,
                    wrongCells = wrongSet,
                    selectedCells = emptyList(),
                    combo = 1
                )
            }

            viewModelScope.launch {
                delay(650)
                _uiState.update {
                    if (it.wrongCells == wrongSet) {
                        it.copy(wrongCells = emptySet())
                    } else it
                }
            }
        }
    }
}
