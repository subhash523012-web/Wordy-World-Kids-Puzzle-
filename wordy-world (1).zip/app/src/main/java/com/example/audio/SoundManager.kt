package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

/**
 * High-performance sound synthesis for Future Tech audio effects.
 * Matches the Web Audio API synthesis from Wordy World.
 */
class SoundManager {
    var soundEnabled: Boolean = true
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    enum class WaveType {
        SINE,
        TRIANGLE,
        SAWTOOTH
    }

    private fun synthesizeTone(
        freq: Double,
        durationMs: Int,
        waveType: WaveType = WaveType.SINE,
        volume: Float = 0.35f
    ): ShortArray {
        val sampleRate = 44100
        val numSamples = (sampleRate * (durationMs / 1000.0)).toInt().coerceAtLeast(1)
        val buffer = ShortArray(numSamples)

        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val rawSample: Double = when (waveType) {
                WaveType.SINE -> sin(2.0 * PI * freq * t)
                WaveType.TRIANGLE -> {
                    val phase = (freq * t) % 1.0
                    if (phase < 0.5) 4.0 * phase - 1.0 else 3.0 - 4.0 * phase
                }
                WaveType.SAWTOOTH -> {
                    val phase = (freq * t) % 1.0
                    2.0 * phase - 1.0
                }
            }

            // Exponential / linear decay envelope
            val decay = 1.0 - (i.toDouble() / numSamples)
            val envelope = decay * decay
            val sampleVal = (rawSample * envelope * volume * Short.MAX_VALUE).toInt()
            buffer[i] = sampleVal.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        return buffer
    }

    private fun playPcm(buffer: ShortArray) {
        if (!soundEnabled) return
        try {
            val sampleRate = 44100
            val minBufSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            val trackSize = buffer.size.coerceAtLeast(minBufSize)
            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(trackSize * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            audioTrack.write(buffer, 0, buffer.size)
            audioTrack.play()
            scope.launch {
                delay((buffer.size * 1000L / sampleRate) + 50)
                try {
                    audioTrack.stop()
                    audioTrack.release()
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {
            // AudioTrack failure fallback
        }
    }

    fun playTone(freq: Double, durationMs: Int, waveType: WaveType = WaveType.SINE, delayMs: Long = 0) {
        if (!soundEnabled) return
        scope.launch {
            if (delayMs > 0) delay(delayMs)
            val buffer = synthesizeTone(freq, durationMs, waveType)
            playPcm(buffer)
        }
    }

    fun playCorrectSound() {
        if (!soundEnabled) return
        // C5, E5, G5
        playTone(523.25, 150, WaveType.SINE, 0)
        playTone(659.25, 150, WaveType.SINE, 100)
        playTone(783.99, 300, WaveType.TRIANGLE, 200)
    }

    fun playWrongSound() {
        if (!soundEnabled) return
        // A3, G3 sawtooth
        playTone(220.0, 200, WaveType.SAWTOOTH, 0)
        playTone(196.0, 250, WaveType.SAWTOOTH, 150)
    }

    fun playCompleteSound() {
        if (!soundEnabled) return
        // Fanfare: C5, E5, G5, C6
        playTone(523.25, 150, WaveType.SINE, 0)
        playTone(659.25, 150, WaveType.SINE, 120)
        playTone(783.99, 150, WaveType.SINE, 240)
        playTone(1046.50, 450, WaveType.TRIANGLE, 360)
    }

    fun playLaserSound() {
        if (!soundEnabled) return
        playTone(880.0, 80, WaveType.SAWTOOTH, 0)
        playTone(1320.0, 100, WaveType.SINE, 60)
        playTone(1760.0, 140, WaveType.TRIANGLE, 120)
    }

    fun playWarpSound() {
        if (!soundEnabled) return
        playTone(440.0, 100, WaveType.SINE, 0)
        playTone(659.25, 120, WaveType.TRIANGLE, 80)
        playTone(880.0, 150, WaveType.SINE, 160)
        playTone(1174.66, 250, WaveType.SINE, 260)
    }
}
