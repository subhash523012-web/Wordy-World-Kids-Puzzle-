package com.example.model

data class CellPos(val r: Int, val c: Int)

data class WordClue(
    val word: String,
    val emoji: String,
    val hint: String
)

data class PlacedWord(
    val word: String,
    val emoji: String,
    val hint: String,
    val cells: List<CellPos>
)

data class GameLevel(
    val level: Int,
    val theme: String,
    val gridSize: Int = 5,
    val words: List<WordClue>
)

data class BoardGenerationResult(
    val grid: List<List<Char>>,
    val placedWords: List<PlacedWord>
)

object GameLevelsRepository {
    val levels: List<GameLevel> = listOf(
        GameLevel(
            level = 1,
            theme = "Space",
            gridSize = 5,
            words = listOf(
                WordClue("JET", "🚀", "I fly fast"),
                WordClue("SUN", "☀️", "I am a star"),
                WordClue("SKY", "🌙", "I am up high"),
                WordClue("UFO", "🛸", "I am a flying saucer"),
                WordClue("FLY", "🐦", "Birds do this")
            )
        ),
        GameLevel(
            level = 2,
            theme = "Space",
            gridSize = 5,
            words = listOf(
                WordClue("MOON", "🌕", "I shine at night"),
                WordClue("STAR", "⭐", "I twinkle in the sky"),
                WordClue("MARS", "🌍", "I am a red planet"),
                WordClue("DARK", "🌑", "Space has no light"),
                WordClue("GLOW", "🔆", "Stars do this")
            )
        ),
        GameLevel(
            level = 3,
            theme = "Robots",
            gridSize = 5,
            words = listOf(
                WordClue("BOT", "🤖", "I am a robot"),
                WordClue("BAT", "🔋", "I give power"),
                WordClue("COG", "⚙️", "I am a wheel"),
                WordClue("NUT", "🔧", "I am a bolt"),
                WordClue("LED", "💡", "I am a light")
            )
        ),
        GameLevel(
            level = 4,
            theme = "Cyber",
            gridSize = 5,
            words = listOf(
                WordClue("CODE", "💻", "Programs are written in this"),
                WordClue("BYTE", "🔢", "8 bits of digital data"),
                WordClue("DATA", "📊", "Raw digital information"),
                WordClue("CHIP", "🔲", "Silicon brain of a computer"),
                WordClue("GRID", "🌐", "Interconnected power network")
            )
        ),
        GameLevel(
            level = 5,
            theme = "Quantum",
            gridSize = 5,
            words = listOf(
                WordClue("ATOM", "⚛️", "Building block of matter"),
                WordClue("WAVE", "〰️", "Oscillating quantum state"),
                WordClue("SPIN", "🔄", "Intrinsic angular momentum"),
                WordClue("BEAM", "🔦", "Focused ray of energy"),
                WordClue("CORE", "🔮", "Central power source")
            )
        ),
        GameLevel(
            level = 6,
            theme = "Future Tech",
            gridSize = 5,
            words = listOf(
                WordClue("LASER", "🔴", "Coherent light beam"),
                WordClue("HYPER", "⚡", "Super high velocity"),
                WordClue("SOLAR", "☀️", "Power from sunlight"),
                WordClue("RADAR", "📡", "Detects distant objects"),
                WordClue("DRONE", "🛸", "Autonomous flying craft")
            )
        ),
        GameLevel(
            level = 7,
            theme = "Neon City",
            gridSize = 5,
            words = listOf(
                WordClue("NEON", "✨", "Bright glowing gas light"),
                WordClue("HACK", "🔓", "Breach computer systems"),
                WordClue("WIRE", "🔌", "Carries electrical current"),
                WordClue("SYNC", "🔄", "Synchronize digital devices"),
                WordClue("CYBER", "🌆", "Futuristic computer culture")
            )
        ),
        GameLevel(
            level = 8,
            theme = "Cosmos",
            gridSize = 5,
            words = listOf(
                WordClue("NOVA", "💥", "Exploding bright star"),
                WordClue("COMET", "☄️", "Icy astronomical body"),
                WordClue("ORBIT", "🛰️", "Curved celestial path"),
                WordClue("ALIEN", "👽", "Being from another world"),
                WordClue("TITAN", "🪐", "Giant moon of Saturn")
            )
        )
    )

    fun generateBoard(level: GameLevel): BoardGenerationResult {
        val size = level.gridSize
        val grid = Array(size) { CharArray(size) { ' ' } }
        val placedList = mutableListOf<PlacedWord>()

        // Directions: Horizontal (0, 1), Vertical (1, 0)
        val dirs = listOf(Pair(0, 1), Pair(1, 0))

        for (item in level.words) {
            val word = item.word.uppercase().trim()
            var placed = false
            var tries = 0

            while (!placed && tries < 300) {
                tries++
                val dir = dirs.random()
                val maxR = if (dir.first == 0) size else size - word.length + 1
                val maxC = if (dir.second == 0) size else size - word.length + 1

                if (maxR <= 0 || maxC <= 0) continue

                val startR = (0 until maxR).random()
                val startC = (0 until maxC).random()

                var canPlace = true
                val coords = mutableListOf<CellPos>()

                for (i in word.indices) {
                    val r = startR + dir.first * i
                    val c = startC + dir.second * i
                    val currentCell = grid[r][c]
                    if (currentCell != ' ' && currentCell != word[i]) {
                        canPlace = false
                        break
                    }
                    coords.add(CellPos(r, c))
                }

                if (canPlace) {
                    for (i in word.indices) {
                        val r = coords[i].r
                        val c = coords[i].c
                        grid[r][c] = word[i]
                    }
                    placedList.add(
                        PlacedWord(
                            word = word,
                            emoji = item.emoji,
                            hint = item.hint,
                            cells = coords
                        )
                    )
                    placed = true
                }
            }
        }

        // Fill remaining cells with random letters
        val alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        for (r in 0 until size) {
            for (c in 0 until size) {
                if (grid[r][c] == ' ') {
                    grid[r][c] = alphabet.random()
                }
            }
        }

        return BoardGenerationResult(
            grid = grid.map { it.toList() },
            placedWords = placedList
        )
    }
}
