package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Wordy World – Future Tech Edition Palette
val BgStart = Color(0xFF0D47A1)
val BgEnd = Color(0xFF080D26)
val GridBg = Color(0xFF101652)
val CellBg = Color(0xFF1F2A7A)
val CellHover = Color(0xFF283593)

val NeonYellow = Color(0xFFFFEA00)
val NeonGreen = Color(0xFF00E676)
val NeonRed = Color(0xFFFF1744)
val NeonPurple = Color(0xFFD500F9)
val NeonCyan = Color(0xFF00E5FF)
val Gold = Color(0xFFFFD700)

val DarkIndigo = Color(0xFF1A237E)
val TextLight = Color(0xFFFFFFFF)
val TextMuted = Color(0xFFB0BEC5)
val WrongRed = Color(0xFFFF5252)

// Standard theme colors
val Purple80 = NeonCyan
val PurpleGrey80 = Color(0xFF8C9EFF)
val Pink80 = NeonPurple

val Purple40 = Color(0xFF1A237E)
val PurpleGrey40 = Color(0xFF283593)
val Pink40 = Color(0xFF4A148C)
