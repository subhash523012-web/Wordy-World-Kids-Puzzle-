package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = NeonGreen,
    onPrimary = Color(0xFF0D3B1E),
    primaryContainer = Color(0xFF1F2A7A),
    onPrimaryContainer = NeonYellow,
    secondary = NeonCyan,
    onSecondary = Color(0xFF002244),
    tertiary = NeonPurple,
    background = BgEnd,
    surface = Color(0xFF0D1B4A),
    onBackground = TextLight,
    onSurface = TextLight,
    error = NeonRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
