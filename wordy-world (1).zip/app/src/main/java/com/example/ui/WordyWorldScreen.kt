package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.NavigateBefore
import androidx.compose.material.icons.filled.NavigateNext
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.audio.SoundManager
import com.example.viewmodel.GameViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

enum class TimerMode { ZEN, RELAXED }

// Theme Colors (Cyber / Neon Glassmorphic)
val BgDark = Color(0xFF070B19)
val CardBg = Color(0x331E293B)
val NeonCyan = Color(0xFF00F5D4)
val NeonYellow = Color(0xFFFFD166)
val NeonGreen = Color(0xFF00E676)
val NeonMagenta = Color(0xFFF72585)
val NeonRed = Color(0xFFFF5252)

// Level Data Model
data class LevelData(
    val levelNumber: Int,
    val theme: String,
    val targetWord: String,
    val emoji: String,
    val clueText: String,
    val gridLetters: List<String>,
    val targetIndices: Set<Int> // Correct positions on grid
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WordyWorldScreen(
    viewModel: GameViewModel = viewModel(),
    modifier: Modifier = Modifier
) {
    val soundManager = remember { SoundManager() }
    val scope = rememberCoroutineScope()

    // 20 Future Tech Cyber Levels
    val levels = remember {
        listOf(
            LevelData(
                levelNumber = 1,
                theme = "Cosmic Core",
                targetWord = "JET",
                emoji = "🚀",
                clueText = "Fly Fast",
                gridLetters = listOf(
                    "Z", "P", "U", "F", "G",
                    "F", "J", "E", "T", "Q",
                    "S", "K", "Y", "U", "T",
                    "N", "O", "B", "W", "D",
                    "J", "E", "T", "Y", "M"
                ),
                targetIndices = setOf(6, 7, 8) // J, E, T
            ),
            LevelData(
                levelNumber = 2,
                theme = "Sky High",
                targetWord = "SKY",
                emoji = "☁️",
                clueText = "Up in the Clouds",
                gridLetters = listOf(
                    "Z", "P", "U", "F", "G",
                    "F", "J", "E", "T", "Q",
                    "S", "K", "Y", "U", "T",
                    "N", "O", "B", "W", "D",
                    "J", "E", "T", "Y", "M"
                ),
                targetIndices = setOf(10, 11, 12) // S, K, Y
            ),
            LevelData(
                levelNumber = 3,
                theme = "Solar Orbit",
                targetWord = "SUN",
                emoji = "☀️",
                clueText = "Cosmic Plasma Star",
                gridLetters = listOf(
                    "S", "U", "N", "A", "B",
                    "M", "A", "R", "S", "C",
                    "M", "O", "O", "N", "D",
                    "S", "T", "A", "R", "E",
                    "P", "L", "A", "N", "T"
                ),
                targetIndices = setOf(0, 1, 2)
            ),
            LevelData(
                levelNumber = 4,
                theme = "Red Planet",
                targetWord = "MARS",
                emoji = "🪐",
                clueText = "Red Horizon Planet",
                gridLetters = listOf(
                    "S", "U", "N", "A", "B",
                    "M", "A", "R", "S", "C",
                    "M", "O", "O", "N", "D",
                    "S", "T", "A", "R", "E",
                    "P", "L", "A", "N", "T"
                ),
                targetIndices = setOf(5, 6, 7, 8)
            ),
            LevelData(
                levelNumber = 5,
                theme = "Night Glow",
                targetWord = "MOON",
                emoji = "🌕",
                clueText = "Shines at Night",
                gridLetters = listOf(
                    "S", "U", "N", "A", "B",
                    "M", "A", "R", "S", "C",
                    "M", "O", "O", "N", "D",
                    "S", "T", "A", "R", "E",
                    "P", "L", "A", "N", "T"
                ),
                targetIndices = setOf(10, 11, 12, 13)
            ),
            LevelData(
                levelNumber = 6,
                theme = "Constellation",
                targetWord = "STAR",
                emoji = "⭐",
                clueText = "Twinkles in Deep Space",
                gridLetters = listOf(
                    "S", "U", "N", "A", "B",
                    "M", "A", "R", "S", "C",
                    "M", "O", "O", "N", "D",
                    "S", "T", "A", "R", "E",
                    "P", "L", "A", "N", "T"
                ),
                targetIndices = setOf(15, 16, 17, 18)
            ),
            LevelData(
                levelNumber = 7,
                theme = "Deep Space",
                targetWord = "UFO",
                emoji = "🛸",
                clueText = "Alien Flying Saucer",
                gridLetters = listOf(
                    "U", "F", "O", "X", "Y",
                    "B", "E", "A", "M", "Z",
                    "W", "A", "R", "P", "K",
                    "A", "T", "O", "M", "Q",
                    "N", "E", "O", "N", "P"
                ),
                targetIndices = setOf(0, 1, 2)
            ),
            LevelData(
                levelNumber = 8,
                theme = "Energy Ray",
                targetWord = "BEAM",
                emoji = "🔦",
                clueText = "Focused Laser Ray",
                gridLetters = listOf(
                    "U", "F", "O", "X", "Y",
                    "B", "E", "A", "M", "Z",
                    "W", "A", "R", "P", "K",
                    "A", "T", "O", "M", "Q",
                    "N", "E", "O", "N", "P"
                ),
                targetIndices = setOf(5, 6, 7, 8)
            ),
            LevelData(
                levelNumber = 9,
                theme = "Hyperspace",
                targetWord = "WARP",
                emoji = "🌀",
                clueText = "Faster Than Light Travel",
                gridLetters = listOf(
                    "U", "F", "O", "X", "Y",
                    "B", "E", "A", "M", "Z",
                    "W", "A", "R", "P", "K",
                    "A", "T", "O", "M", "Q",
                    "N", "E", "O", "N", "P"
                ),
                targetIndices = setOf(10, 11, 12, 13)
            ),
            LevelData(
                levelNumber = 10,
                theme = "Quantum Realm",
                targetWord = "ATOM",
                emoji = "⚛️",
                clueText = "Building Block of Matter",
                gridLetters = listOf(
                    "U", "F", "O", "X", "Y",
                    "B", "E", "A", "M", "Z",
                    "W", "A", "R", "P", "K",
                    "A", "T", "O", "M", "Q",
                    "N", "E", "O", "N", "P"
                ),
                targetIndices = setOf(15, 16, 17, 18)
            ),
            LevelData(
                levelNumber = 11,
                theme = "Robotics Lab",
                targetWord = "BOT",
                emoji = "🤖",
                clueText = "Autonomous Robot Unit",
                gridLetters = listOf(
                    "B", "O", "T", "Q", "R",
                    "B", "A", "T", "S", "T",
                    "C", "O", "G", "U", "V",
                    "L", "E", "D", "W", "X",
                    "C", "H", "I", "P", "Y"
                ),
                targetIndices = setOf(0, 1, 2)
            ),
            LevelData(
                levelNumber = 12,
                theme = "Power Cell",
                targetWord = "BAT",
                emoji = "🔋",
                clueText = "Stores Electric Power",
                gridLetters = listOf(
                    "B", "O", "T", "Q", "R",
                    "B", "A", "T", "S", "T",
                    "C", "O", "G", "U", "V",
                    "L", "E", "D", "W", "X",
                    "C", "H", "I", "P", "Y"
                ),
                targetIndices = setOf(5, 6, 7)
            ),
            LevelData(
                levelNumber = 13,
                theme = "Mechanics",
                targetWord = "COG",
                emoji = "⚙️",
                clueText = "Spinning Machine Wheel",
                gridLetters = listOf(
                    "B", "O", "T", "Q", "R",
                    "B", "A", "T", "S", "T",
                    "C", "O", "G", "U", "V",
                    "L", "E", "D", "W", "X",
                    "C", "H", "I", "P", "Y"
                ),
                targetIndices = setOf(10, 11, 12)
            ),
            LevelData(
                levelNumber = 14,
                theme = "Photonics",
                targetWord = "LED",
                emoji = "💡",
                clueText = "Light Emitting Diode",
                gridLetters = listOf(
                    "B", "O", "T", "Q", "R",
                    "B", "A", "T", "S", "T",
                    "C", "O", "G", "U", "V",
                    "L", "E", "D", "W", "X",
                    "C", "H", "I", "P", "Y"
                ),
                targetIndices = setOf(15, 16, 17)
            ),
            LevelData(
                levelNumber = 15,
                theme = "Hardware Matrix",
                targetWord = "CHIP",
                emoji = "🔲",
                clueText = "Silicon Processor Core",
                gridLetters = listOf(
                    "B", "O", "T", "Q", "R",
                    "B", "A", "T", "S", "T",
                    "C", "O", "G", "U", "V",
                    "L", "E", "D", "W", "X",
                    "C", "H", "I", "P", "Y"
                ),
                targetIndices = setOf(20, 21, 22, 23)
            ),
            LevelData(
                levelNumber = 16,
                theme = "Cyber Code",
                targetWord = "CODE",
                emoji = "💻",
                clueText = "Software Algorithm",
                gridLetters = listOf(
                    "C", "O", "D", "E", "Z",
                    "B", "Y", "T", "E", "K",
                    "G", "R", "I", "D", "L",
                    "H", "A", "C", "K", "M",
                    "N", "E", "O", "N", "P"
                ),
                targetIndices = setOf(0, 1, 2, 3)
            ),
            LevelData(
                levelNumber = 17,
                theme = "Binary",
                targetWord = "BYTE",
                emoji = "🔢",
                clueText = "8 Bits of Data",
                gridLetters = listOf(
                    "C", "O", "D", "E", "Z",
                    "B", "Y", "T", "E", "K",
                    "G", "R", "I", "D", "L",
                    "H", "A", "C", "K", "M",
                    "N", "E", "O", "N", "P"
                ),
                targetIndices = setOf(5, 6, 7, 8)
            ),
            LevelData(
                levelNumber = 18,
                theme = "Power Network",
                targetWord = "GRID",
                emoji = "🌐",
                clueText = "Interconnected Matrix",
                gridLetters = listOf(
                    "C", "O", "D", "E", "Z",
                    "B", "Y", "T", "E", "K",
                    "G", "R", "I", "D", "L",
                    "H", "A", "C", "K", "M",
                    "N", "E", "O", "N", "P"
                ),
                targetIndices = setOf(10, 11, 12, 13)
            ),
            LevelData(
                levelNumber = 19,
                theme = "Optics",
                targetWord = "LASER",
                emoji = "🔴",
                clueText = "Coherent Crimson Ray",
                gridLetters = listOf(
                    "L", "A", "S", "E", "R",
                    "R", "A", "D", "A", "R",
                    "S", "O", "L", "A", "R",
                    "C", "O", "R", "E", "S",
                    "N", "O", "V", "A", "X"
                ),
                targetIndices = setOf(0, 1, 2, 3, 4)
            ),
            LevelData(
                levelNumber = 20,
                theme = "Cosmic Core",
                targetWord = "CORE",
                emoji = "🔮",
                clueText = "Central Power Core",
                gridLetters = listOf(
                    "L", "A", "S", "E", "R",
                    "R", "A", "D", "A", "R",
                    "S", "O", "L", "A", "R",
                    "C", "O", "R", "E", "S",
                    "N", "O", "V", "A", "X"
                ),
                targetIndices = setOf(15, 16, 17, 18)
            )
        )
    }

    // State Management
    var currentLevelIndex by remember { mutableIntStateOf(0) }
    var maxUnlockedLevel by remember { mutableIntStateOf(1) }
    var selectedTiles by remember { mutableStateOf(setOf<Int>()) }
    var wrongTiles by remember { mutableStateOf(setOf<Int>()) }
    var laserHintTiles by remember { mutableStateOf(setOf<Int>()) }
    var foundWordsSet by remember { mutableStateOf(setOf<String>()) }
    var combo by remember { mutableIntStateOf(1) }

    // Stats & Tracking
    var wrongWordCount by remember { mutableIntStateOf(0) }
    var timeTakenSeconds by remember { mutableIntStateOf(0) }
    var lastCompletedTimeTaken by remember { mutableIntStateOf(0) }
    var isLevelCompleted by remember { mutableStateOf(false) }

    // UI Dialogs
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showLevelClearDialog by remember { mutableStateOf(false) }
    var showLevelSelectorDialog by remember { mutableStateOf(false) }

    // Child-Friendly Timer Settings
    var timerMode by remember { mutableStateOf(TimerMode.ZEN) }
    var bonusTrigger by remember { mutableIntStateOf(0) }
    var soundEnabled by remember { mutableStateOf(true) }

    LaunchedEffect(soundEnabled) {
        soundManager.soundEnabled = soundEnabled
    }

    val currentLevel = levels[currentLevelIndex]

    // Active Timer Counter (Counts elapsed time until level ends)
    LaunchedEffect(currentLevelIndex, isLevelCompleted) {
        if (!isLevelCompleted) {
            timeTakenSeconds = 0
            while (!isLevelCompleted) {
                delay(1000L)
                timeTakenSeconds++
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0B1026), BgDark, Color(0xFF050711))
                )
            )
            .drawBehind {
                // Cyber circuit grid lines
                val step = 44.dp.toPx()
                var x = 0f
                while (x < size.width) {
                    drawLine(
                        color = Color(0x0C00F5D4),
                        start = Offset(x, 0f),
                        end = Offset(x, size.height),
                        strokeWidth = 1f
                    )
                    x += step
                }
                var y = 0f
                while (y < size.height) {
                    drawLine(
                        color = Color(0x0C00F5D4),
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = 1f
                    )
                    y += step
                }
            }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 440.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 1. TOP HEADER (Settings, Prev, Level Title & Selector, Next, Sound)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Settings ⚙️ Button
                    IconButton(
                        onClick = { showSettingsDialog = true },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(CardBg)
                            .border(1.dp, Color(0x44FFFFFF), RoundedCornerShape(10.dp))
                            .testTag("btn_settings")
                    ) {
                        Text("⚙️", fontSize = 16.sp)
                    }

                    // < Prev Button
                    Button(
                        onClick = {
                            if (currentLevelIndex > 0) {
                                currentLevelIndex--
                                selectedTiles = emptySet()
                                wrongTiles = emptySet()
                                laserHintTiles = emptySet()
                                isLevelCompleted = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CardBg),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0x33FFFFFF)),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                        modifier = Modifier
                            .height(38.dp)
                            .testTag("btn_prev_level")
                    ) {
                        Icon(
                            imageVector = Icons.Default.NavigateBefore,
                            contentDescription = "Previous Level",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Text("Prev", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Center Level Pill (Clickable to open mission selector)
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x33101833))
                        .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .clickable { showLevelSelectorDialog = true }
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                        .testTag("level_title_header"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LEVEL : ${currentLevel.levelNumber} | ${currentLevel.theme}",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.GridView,
                        contentDescription = "Select Level",
                        tint = NeonCyan,
                        modifier = Modifier.size(13.dp)
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Next > Button
                    Button(
                        onClick = {
                            if (currentLevelIndex + 1 < levels.size) {
                                currentLevelIndex++
                                selectedTiles = emptySet()
                                wrongTiles = emptySet()
                                laserHintTiles = emptySet()
                                isLevelCompleted = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CardBg),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0x33FFFFFF)),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                        modifier = Modifier
                            .height(38.dp)
                            .testTag("btn_next_level")
                    ) {
                        Text("Next", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Icon(
                            imageVector = Icons.Default.NavigateNext,
                            contentDescription = "Next Level",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Sound Toggle
                    IconButton(
                        onClick = { soundEnabled = !soundEnabled },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(CardBg)
                            .border(1.dp, Color(0x33FFFFFF), CircleShape)
                            .testTag("btn_toggle_sound")
                    ) {
                        Icon(
                            imageVector = if (soundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                            contentDescription = if (soundEnabled) "Mute Sound" else "Enable Sound",
                            tint = if (soundEnabled) NeonYellow else Color(0xFFA0AEC0),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // 2. CHILD-FRIENDLY TIMER / PRACTICE MODE
            TimerBarComponent(
                currentMode = timerMode,
                onModeChange = { timerMode = it },
                bonusTrigger = bonusTrigger
            )

            // 3. TARGET WORD CLUE BANNER (Cosmic Nebula Style with Combo)
            ClueBannerComponent(
                level = currentLevel,
                combo = combo
            )

            // 4. 5x5 LETTER GRID WITH VALIDATION & NEON HIGHLIGHTS
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0x22111936))
                    .border(1.2.dp, Color(0x4400F5D4), RoundedCornerShape(20.dp))
                    .padding(8.dp)
                    .testTag("letter_grid_container"),
                contentAlignment = Alignment.Center
            ) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(5),
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    userScrollEnabled = false
                ) {
                    itemsIndexed(currentLevel.gridLetters) { index, letter ->
                        val isSelected = selectedTiles.contains(index)
                        val isFound = isLevelCompleted && currentLevel.targetIndices.contains(index)
                        val isLaser = laserHintTiles.contains(index)
                        val isWrong = wrongTiles.contains(index)

                        TileItemView(
                            letter = letter,
                            index = index,
                            isSelected = isSelected,
                            isFound = isFound,
                            isLaser = isLaser,
                            isWrong = isWrong,
                            onClick = {
                                if (isLevelCompleted) return@TileItemView
                                soundManager.playTone(440.0 + (index * 25.0), 70, SoundManager.WaveType.SINE)

                                val newSelected = if (selectedTiles.contains(index)) {
                                    selectedTiles - index
                                } else {
                                    selectedTiles + index
                                }
                                selectedTiles = newSelected

                                // Check if user completed selection for target word length
                                if (newSelected.size == currentLevel.targetIndices.size) {
                                    if (newSelected == currentLevel.targetIndices) {
                                        // Correct Word Found!
                                        soundManager.playCorrectSound()
                                        bonusTrigger++
                                        combo++
                                        lastCompletedTimeTaken = timeTakenSeconds
                                        isLevelCompleted = true
                                        foundWordsSet = foundWordsSet + currentLevel.targetWord

                                        if (maxUnlockedLevel <= currentLevel.levelNumber) {
                                            maxUnlockedLevel = currentLevel.levelNumber + 1
                                        }

                                        scope.launch {
                                            delay(350)
                                            soundManager.playCompleteSound()
                                            showLevelClearDialog = true
                                        }
                                    } else {
                                        // Wrong Attempt!
                                        soundManager.playWrongSound()
                                        wrongWordCount++
                                        combo = 1
                                        wrongTiles = newSelected
                                        scope.launch {
                                            delay(700)
                                            wrongTiles = emptySet()
                                            selectedTiles = emptySet()
                                        }
                                    }
                                }
                            }
                        )
                    }
                }
            }

            // 5. FOUND WORDS & PROGRESS DASHBOARD
            FoundWordsDashboard(
                currentLevel = currentLevel,
                isCompleted = isLevelCompleted,
                foundWords = foundWordsSet,
                wrongAttempts = wrongWordCount
            )

            // 6. CYBER 3D PERSPECTIVE FLOOR WITH BOOSTERS
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(115.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0x1A000000)),
                contentAlignment = Alignment.Center
            ) {
                // Perspective wireframe grid floor behind boosters
                CyberPerspectiveFloor(
                    modifier = Modifier.fillMaxSize()
                )

                // Booster Buttons floating above the 3D grid
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BoosterButton(
                        title = "Laser Hint",
                        icon = "🔑",
                        glowColor = NeonMagenta,
                        testTag = "btn_laser_hint"
                    ) {
                        soundManager.playLaserSound()
                        // Reveal target indices with laser highlight
                        laserHintTiles = currentLevel.targetIndices
                        scope.launch {
                            delay(2500)
                            laserHintTiles = emptySet()
                        }
                    }

                    BoosterButton(
                        title = "Time Warp",
                        icon = "⏱️",
                        glowColor = NeonCyan,
                        testTag = "btn_time_warp"
                    ) {
                        soundManager.playWarpSound()
                        bonusTrigger++
                    }
                }
            }
        }

        // --- LEVEL COMPLETE DIALOG ---
        if (showLevelClearDialog) {
            AlertDialog(
                onDismissRequest = { },
                confirmButton = {
                    Button(
                        onClick = {
                            showLevelClearDialog = false
                            isLevelCompleted = false
                            selectedTiles = emptySet()
                            wrongTiles = emptySet()
                            laserHintTiles = emptySet()
                            if (currentLevelIndex + 1 < levels.size) {
                                currentLevelIndex++
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("btn_next_mission")
                    ) {
                        Text(
                            if (currentLevelIndex + 1 < levels.size) "Go to Level ${currentLevelIndex + 2} 🚀" else "Play Again 🔄",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                title = {
                    Text(
                        "🎉 Level ${currentLevel.levelNumber} Complete!",
                        color = NeonYellow,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Shabash! Aapne shabd dhoondh liya.", color = Color.White, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("⏱️ Total Time Taken: ${lastCompletedTimeTaken}s", color = NeonCyan, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text("❌ Mistakes / Wrong: $wrongWordCount", color = NeonRed, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                },
                containerColor = Color(0xFF131B36),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.testTag("level_complete_dialog")
            )
        }

        // --- SETTINGS DIALOG (Stats, Ending Time, Progress & Wrong Word Count) ---
        if (showSettingsDialog) {
            AlertDialog(
                onDismissRequest = { showSettingsDialog = false },
                confirmButton = {
                    TextButton(onClick = { showSettingsDialog = false }) {
                        Text("Close", color = NeonCyan, fontWeight = FontWeight.Bold)
                    }
                },
                title = {
                    Text("⚙️ Game Stats & Settings", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // 1. Ending Time count of last completed level
                        StatItem(
                            title = "Ending Time (Last Finished)",
                            value = if (lastCompletedTimeTaken > 0) "${lastCompletedTimeTaken} sec" else "Not completed yet",
                            accentColor = NeonYellow
                        )

                        // 2. Progress Count
                        StatItem(
                            title = "Level Progress",
                            value = "Level ${currentLevel.levelNumber} (Max Unlocked: L${maxUnlockedLevel})",
                            accentColor = NeonCyan
                        )

                        // 3. Wrong Words / Mistakes Count
                        StatItem(
                            title = "Wrong Word Attempts",
                            value = "$wrongWordCount times",
                            accentColor = NeonRed
                        )

                        HorizontalDivider(color = Color(0x33FFFFFF), thickness = 1.dp)

                        // Reset Stats Option
                        Button(
                            onClick = {
                                wrongWordCount = 0
                                lastCompletedTimeTaken = 0
                                showSettingsDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0x33FF5252)),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Reset Mistakes & Time Stats", color = Color.White, fontSize = 12.sp)
                        }
                    }
                },
                containerColor = Color(0xFF131B36),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.testTag("settings_dialog")
            )
        }

        // --- MISSION / LEVEL SELECTOR DIALOG ---
        if (showLevelSelectorDialog) {
            Dialog(onDismissRequest = { showLevelSelectorDialog = false }) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .testTag("level_selector_dialog"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0A102C)),
                    border = BorderStroke(2.dp, NeonCyan)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Select Mission",
                                color = NeonCyan,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "✕",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable { showLevelSelectorDialog = false }
                                    .padding(4.dp)
                            )
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(340.dp)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            levels.forEachIndexed { index, level ->
                                val isCurrent = index == currentLevelIndex
                                val isUnlocked = level.levelNumber <= maxUnlockedLevel

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isCurrent) Color(0xFF192557) else Color(0xFF0F1738))
                                        .border(
                                            1.dp,
                                            if (isCurrent) NeonYellow else Color(0x22FFFFFF),
                                            RoundedCornerShape(10.dp)
                                        )
                                        .clickable {
                                            currentLevelIndex = index
                                            selectedTiles = emptySet()
                                            wrongTiles = emptySet()
                                            laserHintTiles = emptySet()
                                            isLevelCompleted = false
                                            showLevelSelectorDialog = false
                                        }
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(level.emoji, fontSize = 18.sp)
                                        Column {
                                            Text(
                                                text = "LEVEL ${level.levelNumber}: ${level.theme}",
                                                color = if (isCurrent) NeonYellow else Color.White,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "Target: ${level.targetWord} • ${level.clueText}",
                                                color = Color(0xFFA0AEC0),
                                                fontSize = 11.sp
                                            )
                                        }
                                    }

                                    if (isCurrent) {
                                        Text(
                                            text = "PLAYING",
                                            color = NeonGreen,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                    } else if (!isUnlocked) {
                                        Text(
                                            text = "🔒",
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------------- SUB-COMPONENTS ----------------------

@Composable
fun TileItemView(
    letter: String,
    index: Int,
    isSelected: Boolean,
    isFound: Boolean,
    isLaser: Boolean,
    isWrong: Boolean,
    onClick: () -> Unit
) {
    val shakeOffset = remember { Animatable(0f) }

    LaunchedEffect(isWrong) {
        if (isWrong) {
            for (i in 0..3) {
                val dir = if (i % 2 == 0) 5f else -5f
                shakeOffset.animateTo(dir, tween(40))
            }
            shakeOffset.animateTo(0f, tween(40))
        } else {
            shakeOffset.snapTo(0f)
        }
    }

    val scale by animateFloatAsState(
        targetValue = when {
            isLaser -> 1.08f
            isSelected -> 1.06f
            isFound -> 1.04f
            else -> 1.0f
        },
        label = "tile_scale"
    )

    val backgroundColor = when {
        isWrong -> Color(0x66FF1744)
        isLaser -> NeonMagenta.copy(alpha = 0.38f)
        isFound -> NeonGreen.copy(alpha = 0.38f)
        isSelected -> NeonCyan.copy(alpha = 0.28f)
        else -> Color(0x441E293B)
    }

    val borderColor = when {
        isWrong -> Color(0xFFFF1744)
        isLaser -> NeonMagenta
        isFound -> NeonGreen
        isSelected -> NeonCyan
        else -> Color(0x22FFFFFF)
    }

    val borderWidth = when {
        isWrong || isLaser || isFound || isSelected -> 2.dp
        else -> 1.dp
    }

    val textColor = when {
        isWrong -> Color.White
        isLaser -> NeonMagenta
        isFound -> NeonGreen
        isSelected -> NeonCyan
        else -> Color(0xFFE2E8F0)
    }

    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .offset { IntOffset(shakeOffset.value.roundToInt(), 0) }
            .scale(scale)
            .clip(RoundedCornerShape(12.dp))
            .background(backgroundColor)
            .border(borderWidth, borderColor, RoundedCornerShape(12.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() }
            .testTag("tile_$index"),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = letter,
            color = textColor,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun ClueBannerComponent(
    level: LevelData,
    combo: Int
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(105.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        Color(0xFF190638),
                        Color(0xFF38085C),
                        Color(0xFF240046),
                        Color(0xFF0F1B4C)
                    )
                )
            )
            .border(1.5.dp, Color(0x5500F5D4), RoundedCornerShape(20.dp))
            .drawBehind {
                // Subtle glowing nebulae
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color(0x44F72585), Color.Transparent),
                        center = Offset(size.width * 0.4f, size.height * 0.4f),
                        radius = size.width * 0.45f
                    )
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color(0x3300F5D4), Color.Transparent),
                        center = Offset(size.width * 0.75f, size.height * 0.6f),
                        radius = size.width * 0.4f
                    )
                )
            }
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .testTag("clue_banner_component")
    ) {
        // Combo Badge in Top Right
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0x33FFD166))
                .border(1.dp, NeonYellow.copy(alpha = 0.8f), RoundedCornerShape(10.dp))
                .padding(horizontal = 8.dp, vertical = 3.dp)
                .testTag("combo_badge")
        ) {
            Text(
                text = "Combo x$combo 🔥",
                color = NeonYellow,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Main Center Clue Information
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = level.emoji,
                fontSize = 30.sp,
                modifier = Modifier.testTag("clue_emoji")
            )
            Text(
                text = level.targetWord,
                color = NeonYellow,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 19.sp,
                letterSpacing = 3.sp,
                modifier = Modifier.testTag("clue_word")
            )
            Text(
                text = level.clueText,
                color = Color(0xFFA0AEC0),
                fontSize = 11.sp,
                modifier = Modifier.testTag("clue_hint")
            )
        }
    }
}

@Composable
fun TimerBarComponent(
    currentMode: TimerMode,
    onModeChange: (TimerMode) -> Unit,
    bonusTrigger: Int
) {
    var secondsLeft by remember { mutableIntStateOf(180) }
    var showBonus by remember { mutableStateOf(false) }

    LaunchedEffect(bonusTrigger) {
        if (bonusTrigger > 0 && currentMode == TimerMode.RELAXED) {
            secondsLeft += 15
            showBonus = true
            delay(1200)
            showBonus = false
        }
    }

    LaunchedEffect(currentMode, secondsLeft) {
        if (currentMode == TimerMode.RELAXED && secondsLeft > 0) {
            delay(1000L)
            secondsLeft--
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("timer_bar_component"),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Zen vs Relaxed Mode Selector
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0x441E293B))
                .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(16.dp))
                .padding(3.dp)
        ) {
            Text(
                text = "Zen 🧘",
                color = if (currentMode == TimerMode.ZEN) NeonCyan else Color.Gray,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (currentMode == TimerMode.ZEN) Color(0x3300F5D4) else Color.Transparent)
                    .clickable { onModeChange(TimerMode.ZEN) }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .testTag("btn_mode_zen")
            )
            Text(
                text = "Relaxed ⏳",
                color = if (currentMode == TimerMode.RELAXED) NeonYellow else Color.Gray,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (currentMode == TimerMode.RELAXED) Color(0x33FFD166) else Color.Transparent)
                    .clickable {
                        secondsLeft = 180
                        onModeChange(TimerMode.RELAXED)
                    }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .testTag("btn_mode_relaxed")
            )
        }

        // Status or Countdown Display
        Box(contentAlignment = Alignment.Center) {
            if (currentMode == TimerMode.ZEN) {
                Text(
                    text = "No Pressure ✨",
                    color = NeonGreen,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.testTag("zen_status_text")
                )
            } else {
                val mins = secondsLeft / 60
                val secs = secondsLeft % 60
                Text(
                    text = String.format("⏰ %02d:%02d", mins, secs),
                    color = if (secondsLeft <= 15) NeonMagenta else NeonYellow,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.testTag("relaxed_timer_text")
                )

                    androidx.compose.animation.AnimatedVisibility(
                        visible = showBonus,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        Text(
                            text = "+15s ⭐",
                            color = NeonGreen,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.sp,
                            modifier = Modifier.offset(y = (-20).dp)
                        )
                    }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FoundWordsDashboard(
    currentLevel: LevelData,
    isCompleted: Boolean,
    foundWords: Set<String>,
    wrongAttempts: Int
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x33000000))
            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(14.dp))
            .padding(12.dp)
            .testTag("found_words_section")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "🟢 Found Words",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "❌ Wrong Attempts: $wrongAttempts",
                    color = if (wrongAttempts > 0) NeonRed else Color(0xFFA0AEC0),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Text(
                text = if (isCompleted) "Target located! Proceed to next sector." else "Tap letters to form the target word: ${currentLevel.targetWord}",
                color = Color(0xFFA0AEC0),
                fontSize = 11.sp
            )

            // Progress bar
            val progressFraction = if (isCompleted) 1.0f else 0.2f
            val animatedProgress by animateFloatAsState(
                targetValue = progressFraction,
                animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing),
                label = "progress_anim"
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF1E293B))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(animatedProgress)
                        .height(6.dp)
                        .background(
                            Brush.horizontalGradient(listOf(NeonYellow, NeonGreen))
                        )
                )
            }

            if (foundWords.isNotEmpty()) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    foundWords.forEach { word ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0x3300E676))
                                .border(1.dp, NeonGreen, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                .testTag("found_chip_$word")
                        ) {
                            Text(
                                text = "✨ $word",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CyberPerspectiveFloor(
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        val horizonY = 0f
        val vanishingX = width / 2f

        // Horizontal perspective lines with accelerating density towards horizon
        val numHorizontals = 8
        for (i in 1..numHorizontals) {
            val progress = i / numHorizontals.toFloat()
            val y = horizonY + height * (progress * progress)
            val alpha = (progress * 0.4f).coerceIn(0.05f, 0.4f)
            drawLine(
                color = NeonCyan.copy(alpha = alpha),
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 1.2f
            )
        }

        // Perspective rays radiating from vanishing point
        val numRays = 12
        for (i in 0..numRays) {
            val bottomX = (width / numRays) * i
            val spreadFactor = (bottomX - vanishingX) * 2.0f
            val targetX = vanishingX + spreadFactor
            drawLine(
                color = NeonCyan.copy(alpha = 0.28f),
                start = Offset(vanishingX, horizonY - 10f),
                end = Offset(targetX, height),
                strokeWidth = 1.2f
            )
        }
    }
}

@Composable
fun BoosterButton(
    title: String,
    icon: String,
    glowColor: Color,
    testTag: String = "",
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onClick() }
            .testTag(testTag)
    ) {
        Box(
            modifier = Modifier.size(56.dp),
            contentAlignment = Alignment.Center
        ) {
            // Outer glow ring
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .border(2.dp, glowColor.copy(alpha = 0.45f), CircleShape)
            )
            // Inner glowing circle
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(glowColor.copy(alpha = 0.3f), Color(0x44101833))
                        )
                    )
                    .border(2.dp, glowColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(icon, fontSize = 22.sp)
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = title,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun StatItem(title: String, value: String, accentColor: Color) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0x331E293B))
            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(12.dp))
            .padding(10.dp)
    ) {
        Text(title, color = Color(0xFFA0AEC0), fontSize = 12.sp)
        Text(value, color = accentColor, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}
